package com.dinarns.money;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "tPengeluaran") //Membuat tabel baru dengan nama "mahasiswa"
    public class pengeluaran implements Serializable {

        //Membuat kolom ID
        @NonNull
        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "id")
        private
        Integer id;

        //Membuat kolom judul
        @ColumnInfo(name = "judul")
        private
        String judul;


        //tanggal
        @ColumnInfo(name = "tanggal")
        private
        String tanggal;

         //jumlah
         @ColumnInfo(name = "jumlah")
         private
         Integer jumlah;

        //Method untuk mengambil data id
        @NonNull
        public Integer getid() {
            return id;
        }

        //Method untuk memasukan data id
        public void setid(@NonNull Integer id) {
            this.id = id;
        }

        //Method untuk mengambil data judul
        public String getjudul() {
            return judul;
        }


        //Method untuk mengambil data tanggal
        public String gettanggal() {
            return tanggal;
        }

        //Method untuk memasukan data Tanggal
        public void settanggal(String tanggal) {
            this.tanggal = tanggal;
        }

        //Method untuk mengambil data jumlah
        public Integer getjumlah() {
            return jumlah;
        }

        //Method untuk memasukan data jumlah
        public void setJumlah(Integer jurusan) {
            this.jumlah = jumlah;
        }

    }

