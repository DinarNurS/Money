package com.dinarns.money;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;

@Dao
public interface pengeluaranDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertPengeluaran(pengeluaran pengeluaran);
}